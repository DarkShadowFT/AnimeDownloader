import os
import time
from datetime import datetime
from selenium import webdriver


def new_ep(f, ep_num):
	file_nums = f.read()
	file_nums = file_nums.split('\n')
	for i in range(0, len(file_nums)):
		if file_nums[i] == str(ep_num):
			return False
	return True


def close_files(files):
	for f in files:
		f.close()


def download_anime():
	path = "C:\\Users\\r2fpdvzocm5ydw\\PycharmProjects\\AnimeDownloader\\"
	files = [open(os.path.join(path, "Kobayashi Released Episodes.txt"), "a"),
			open(os.path.join(path, "Boruto Released Episodes.txt"), "a"), open(os.path.join(path, "BNHA.txt"), "a")]
	kobayashi_flag, boruto_flag, bnha_flag = False, False, False
	new_ep_found = True
	names = driver.find_element_by_id("menu1").find_elements_by_tag_name("table")
	for i in range(0, len(names)):
		if names[i].text.lower().find(anime_names[0].lower()) != -1 or \
				names[i].text.lower().find(anime_names[1].lower()) != -1 or \
				names[i].text.lower().find(anime_names[2].lower()) != -1:

			nums = [int(s) for s in names[i].text.split() if s.isdigit()]
			ep_num = int(nums[0])

			if names[i].text.lower().find(anime_names[0].lower()) != -1:
				kobayashi_flag = True
				f = open("Kobayashi Released Episodes.txt", "r")
				new_ep_found = new_ep(f, ep_num)
				f.close()

			elif names[i].text.lower().find(anime_names[1].lower()) != -1:
				boruto_flag = True
				f = open("Boruto Released Episodes.txt", "r")
				new_ep_found = new_ep(f, ep_num)
				f.close()

			elif names[i].text.lower().find(anime_names[2].lower()) != -1:
				bnha_flag = True
				f = open("BNHA.txt", "r")
				new_ep_found = new_ep(f, ep_num)
				f.close()

			if new_ep_found:
				elem = names[i].find_element_by_tag_name("tbody").find_element_by_tag_name("tr")
				elem = elem.find_element_by_tag_name("th").find_elements_by_tag_name("a")
				elem[1].click()
				table = driver.find_element_by_id("menu1").find_element_by_tag_name("table")
				el = table.find_element_by_tag_name("tbody").find_element_by_tag_name("tr").find_element_by_tag_name("th")
				el.find_elements_by_tag_name("a")[1].click()
				el = driver.find_element_by_class_name("entry-content").find_element_by_tag_name(
					"table").find_element_by_tag_name("tbody")
				table_rows = el.find_elements_by_tag_name("tr")
				el = el.find_element_by_class_name("link-1080p")
				el.find_element_by_tag_name("a").click()
				el = table_rows[2].find_elements_by_tag_name("th")
				el = el[1].find_elements_by_tag_name("a")
				el[1].click()
				print("Clicked on the magnet link")

				if kobayashi_flag:
					files[0].write(str(ep_num) + "\n")
					close_files(files)
				elif boruto_flag:
					files[1].write(str(ep_num) + "\n")
					close_files(files)
				elif bnha_flag:
					files[2].write(str(ep_num) + "\n")
					close_files(files)
				return

	current_time = datetime.now().strftime("%H:%M:%S")
	print("No new ep released - " + current_time)


driver = webdriver.Chrome()
url = "https://beta.erai-raws.info/"
close = False
anime_names = ["Kobayashi-san Chi no Maid Dragon S", "Boruto: Naruto Next Generations", "Boku no Hero Academia 5th "
															"Season"]

while not close:
	driver.get(url)
	download_anime()
	time.sleep(1200)

driver.close()
